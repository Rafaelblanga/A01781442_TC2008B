function findFirstNonRepeatedChar(str) {
    var arr = str.split('');
    var len = arr.length;
    var char = '';
    var charCount = 0;
    for (var i = 0; i < len; i++) {
        char = arr[i];
        for (var j = 0; j < len; j++) {
            if (char == arr[j]) {
                charCount++;
            }
        }
        if (charCount < 2) {
            return char;
        }
    }
    return null;
}

console.log(findFirstNonRepeatedChar('abacddbec'));


